# Welcome 👋

A shared space for our projects.

- **How we work:** see [CONTRIBUTING.md](https://github.com/HashimWaqar-Ideas/.github/blob/main/CONTRIBUTING.md)
- **Starting a new repo?** Copy [`templates/CLAUDE.md`](https://github.com/HashimWaqar-Ideas/.github/blob/main/templates/CLAUDE.md) into it.
